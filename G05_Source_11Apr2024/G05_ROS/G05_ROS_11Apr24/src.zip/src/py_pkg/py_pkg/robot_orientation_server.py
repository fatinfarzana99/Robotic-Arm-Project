import rclpy
from rclpy.node import Node

from robot_interfaces.srv import JointAnglesToQuaternion

import math

class compute_quaternion_node(Node):
    def __init__(self):
        super().__init__('robot_orientation_server')
        self.get_logger().info("Robot Orientation server has been started.")
        self.compute_quaternion_service = self.create_service(JointAnglesToQuaternion,  'compute_quaternion', self.callback_compute_quaternion)

    def callback_compute_quaternion(self, request, response):
        self.get_logger().info(f"Joint Angles a1,a2,a3:{request.a1:.1f},{request.a2:.1f},{request.a3:.1f}")

        pi = 3.14159265358979323846

        t1 = request.a1 * (pi/180.0)
        t2 = request.a2 * (pi/180.0)
        t3 = request.a3 * (pi/180.0)

        s3 = math.sin(t3)
        c3 = math.cos(t3)

        s12 = math.sin(t1 + t2)
        c12 = math.cos(t1 + t2)

        r11 = -s12 * s3
        r12 = -s12 * c3
        r13 = c12

        r21 = c12 * s3
        r22 = c12 * c3
        r23 = s12

        r31 = -c3
        r32 =  s3
        r33 = 0

        # convert to quaternion, using Cayley's method
        # this implementation should be robust against divide by 0 and sqrt negative number
        response.w = 0.25 * math.sqrt((r11+r22+r33+1)**2 + (r32-r23)**2 + (r13-r31)**2 + (r21-r12)**2)
        response.x = 0.25 * math.sqrt((r32-r23)**2 + (r11-r22-r33+1)**2 + (r21+r12)**2 + (r31+r13)**2)
        response.y = 0.25 * math.sqrt((r13-r31)**2 + (r21+r12)**2 + (r22-r11-r33+1)**2 + (r32+r23)**2)
        response.z = 0.25 * math.sqrt((r21-r12)**2 + (r31+r13)**2 + (r32+r23)**2 + (r33-r11-r22+1)**2)

        #python math library has no signum function, we use copysign instead
        response.x = math.copysign(response.x, (r32-r23))
        response.y = math.copysign(response.y, (r13-r31))
        response.z = math.copysign(response.z, (r21-r12))

        self.get_logger().info(f"Quaternion q1,q2,q3,q4:{response.x:.6f},{response.y:.6f},{response.z:.6f},{response.w:.6f}")
        return response

def main(args = None):
    rclpy.init(args = args)
    node = compute_quaternion_node()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

# END OF FILE #
